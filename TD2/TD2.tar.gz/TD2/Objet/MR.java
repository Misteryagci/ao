public final class MR extends NoeudUnaire {

	public MR ()
	{
		super();
		this.setContenu("MR");
	}
	public double calcul ()
	{
		return super.m.getContenu();
	}
}
