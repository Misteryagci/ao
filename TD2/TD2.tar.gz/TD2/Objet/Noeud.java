public  class Noeud {
	public Noeud ()	{}
	public double calcul(){return 0;}
}
