public final class MMoins extends NoeudUnaire {

	public MMoins ()
	{
		super();
		this.setContenu("M-");
	}
	public void calcul ()
	{
		super.m.soust(fils.calcul());
	}
}
