public final class Plus extends NoeudBinaire {
	public Plus ()
	{
		super();
		this.setContenu("+");
	}
	public double calcul ()
	{
		return fg.calcul()+fd.calcul();
	}
}
