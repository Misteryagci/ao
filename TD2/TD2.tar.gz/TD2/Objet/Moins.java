public final class Moins extends NoeudBinaire {
	public Moins ()
	{
		super();
		this.setContenu("-");
	}
	@Override
	public double calcul ()
	{
		return fg.calcul()-fd.calcul();
	}
}
