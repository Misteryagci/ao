public final class MS extends NoeudUnaire {

	public MS ()
	{
		super();
		this.setContenu("MS");
	}
	public void calcul ()
	{
	 super.m.replace(fils.calcul());
	}
}
