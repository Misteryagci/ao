public final class MPlus extends NoeudUnaire {

	public MPlus ()
	{
		super();
		this.setContenu("M+");
	}
	public void calcul ()
	{
		super.m.ajouter(fils.calcul());
	}
}
