public final class Fois extends NoeudBinaire {
	public Fois ()
	{
		super();
		this.setContenu("*");
	}
	public double calcul ()
	{
		return fg.calcul()*fd.calcul();
	}
}
