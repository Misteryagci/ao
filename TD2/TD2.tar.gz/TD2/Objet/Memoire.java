public class Memoire {
	
	private double contenu;
	public Memoire ()
	{
		contenu = 0;
	}
	public Memoire (double d)
	{
		contenu = d;
	}
	public void replace (double d)
	{
		contenu = d;
	}
	public double getContent()
	{
		return contenu;
	}
	public void ajouter (double d)
	{
		this.contenu+=d;
	} 
	public void soust (double d)
	{
		this.contenu-=d;
	}
	public double getContenu()
	{
		return contenu;
	} 
	public void reset ()
	{
		this.contenu = 0;
	}
}
