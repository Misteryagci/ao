public final class MC extends NoeudUnaire {

	public MC ()
	{
		super();
		this.setContenu("MC");
	}
	@Override
	public void calcul ()
	{
		 super.m.reset();
	}
}
