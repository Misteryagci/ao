public final class Egale extends NoeudUnaire {

	public Egale ()
	{
		super();
		this.setContenu("=");
	}
	public double calcul ()
	{
		 return fils.calcul();
	}
}
