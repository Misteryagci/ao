public final class Valeur extends Noeud{

	private double content;
	
	public Valeur(double d)
	{
		this.content = d;
	}
	public double getContent()
	{
		return content;
	}
	public void setContent (double d)
	{
		this.content = d;
	}
	public String toString ()
	{
		return ""+content;
	}
	public double calcul ()
	{
		return content;
	}	
}
