public abstract class NoeudUnaire extends Noeud{
	protected String contenu;
	protected Noeud fils;
	protected Memoire m;

	public NoeudUnaire ()
	{
		this.contenu = "";
		this.fils = new Noeud ();
		this.m = new Memoire();
	} 
	public NoeudUnaire (String s)
	{
		this.contenu = s;
		this.fils = new Noeud ();	
		this.m = new Memoire();
	}
	public String getContenu ()
	{
		return contenu;
	}
	public void setContenu (String s)
	{
		this.contenu = s;
	}
	public void setFils(Noeud f)
	{
		this.fils = f;
	}
	public Noeud getFils ()
	{
		return this.fils;
	}
	public String toString()
	{
		return fils.toString()+" "+contenu;
	}
	public void setMemoire (Memoire m)
	{
		this.m = m;	
	}
	public Memoire getMemoire ()
	{
		return m;
	}
	
}
