public final class Divise extends NoeudBinaire {
	public Divise ()
	{
		super();
		this.setContenu("/");
	}
	public double calcul ()
	{
		return (super.fg.calcul())/(super.fd.calcul());
	}
}
