public abstract class NoeudBinaire extends Noeud{
	protected String contenu;
	protected Noeud fg,fd;
	
	public NoeudBinaire ()
	{
		this.contenu = "";
		this.fg = new Noeud ();
		this.fd = new Noeud ();
	} 
	public NoeudBinaire (String s)
	{
		this.contenu = s;
		this.fg = new Noeud ();
		this.fd = new Noeud ();
	}
	public String getContenu ()
	{
		return contenu;
	}
	public void setContenu (String s)
	{
		this.contenu = s;
	}
	public void setFG(Noeud f)
	{
		this.fg = f;
	}
	public void setFD(Noeud f)
	{
		this.fd = f;
	}

	public Noeud getFD()
	{	
		return fd;
	}
	public Noeud getFG()
	{
		return fg;
	}
	public String toString()
	{
		return fg.toString()+" "+contenu+" "+fd.toString();
	}
	//public abstract double calcul();
	
}
